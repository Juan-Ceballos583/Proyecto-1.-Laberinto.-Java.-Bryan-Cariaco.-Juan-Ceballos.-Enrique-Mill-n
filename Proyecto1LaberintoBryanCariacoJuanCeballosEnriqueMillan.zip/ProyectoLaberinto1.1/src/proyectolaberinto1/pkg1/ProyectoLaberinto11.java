package proyectolaberinto1.pkg1;

import EstructurasDeDatos.Vertice;
import EstructurasDeDatos.Grafo;
import EstructurasDeDatos.ArbolExpansionMinimo;
import EstructurasDeDatos.Arista;
import java.util.Arrays;

/**
 *
 * @author Bryan Cariaco
 */
public class ProyectoLaberinto11 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        uilaberinto ventana= new uilaberinto();
      ventana.setVisible(true);
        
//        Grafo nuevoGrafo = new Grafo(4);
//        for (int i = 0; i < 4; i++) {
//            Vertice nuevoVertice = new Vertice(i);
//            nuevoGrafo.agregarVertice(nuevoVertice);
//        }
//        System.out.println(Arrays.toString(nuevoGrafo.getTablaAdyacencia()));
//
//        nuevoGrafo.agregarArista(0, 1, 10);
//        nuevoGrafo.agregarArista(0, 3, 12);
//        nuevoGrafo.agregarArista(0, 2, 8);
//        nuevoGrafo.agregarArista(1, 3, 4);
//        nuevoGrafo.agregarArista(1, 2, 7);
//        nuevoGrafo.agregarArista(2, 3, 2);
//        //nuevoGrafo.agregarArista(3, 2, 2);
//        
//        Vertice auxVertice = nuevoGrafo.getTablaAdyacencia()[2];
//        System.out.println(auxVertice);
//        Arista auxArista = auxVertice.getAdyacencias().getAristaMenor();
//        System.out.println(auxArista);
        /*for (int i = 0;i < 7;i++) {
            nuevoGrafo.getTablaAdyacencia()[i].getAdyacencias().imprimir();
        }*/
        //ArbolExpansionMinimo nuevoArbol = new ArbolExpansionMinimo(nuevoGrafo);

        //int[] arreglo = nuevoArbol.AlgoritmoPrim(3);
        //System.out.println(Arrays.toString(arreglo));
    }
//    public static void ui() {
//      uilaberinto ventana= new uilaberinto();
//      ventana.setVisible(true);
    }
    
    
    
    
    
    
    
    
    
    
    
//}
