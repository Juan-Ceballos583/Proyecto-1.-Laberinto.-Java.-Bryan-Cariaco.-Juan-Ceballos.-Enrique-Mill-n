package EstructurasDeDatos;

//import java.util.Arrays;

/**
 *
 * @author Bryan Cariaco
 */
public class ArbolExpansionMinimo {

    private Vertice[] listaAdyacencia;
    private int numeroVertices;

    public ArbolExpansionMinimo(Grafo grafoActual) {
        listaAdyacencia = grafoActual.getTablaAdyacencia();
        numeroVertices = grafoActual.getNumMaxVertices();
    }

    public int[] AlgoritmoPrim(int verticeInicial) {
        int[] vertices = new int[numeroVertices];
        for (int i = 0; i < numeroVertices; i++) {
            vertices[i] = i;
        }

        int[] verticesProcesados = new int[numeroVertices];
        int[] adyacencias = new int[numeroVertices];

        int auxVertices = numeroVertices;
        int cuentaVertices = 0;

        while (auxVertices != cuentaVertices) {
            if (cuentaVertices == 0) {
                verticesProcesados[verticeInicial] = verticeInicial;
                cuentaVertices++;
                Vertice auxVertice = listaAdyacencia[verticeInicial];
                Arista auxArista = auxVertice.getAdyacencias().getAristaMenor();
                if (auxArista != null) {
                    int destino = auxArista.getDestino();
                    verticesProcesados[destino] = destino;
                    adyacencias[verticeInicial] = destino;
                    cuentaVertices++;
                }
            } else {
                Arista aristaMenor = null;
                int verticeControl = 0;
                for (int i = 0; i < auxVertices; i++) {
                    if (vertices[i] != verticesProcesados[i]) {
                        Vertice auxVertice = listaAdyacencia[i];
                        if (aristaMenor == null) {
                            aristaMenor = auxVertice.getAdyacencias().getAristaMenor();
                            verticeControl = i;
                        } else {
                            Arista auxArista = auxVertice.getAdyacencias().getAristaMenor();
                            if (aristaMenor.getPeso() > auxArista.getPeso()) {
                                aristaMenor = auxArista;
                                verticeControl = i;
                            }

                        }
                    }
                }
                if (aristaMenor != null) {
                    int destino = aristaMenor.getDestino();
                    adyacencias[verticeControl] = destino;
                    verticesProcesados[verticeControl] = verticeControl;
                    cuentaVertices++;
                }
            }
        }

        /*System.out.println(Arrays.toString(listaAdyacencia));
        System.out.println(numeroVertices);

        int[] vertices = new int[numeroVertices];
        for (int i = 0; i < numeroVertices; i++) {
            vertices[i] = i;
        }

        int[] verticesProcesados = new int[numeroVertices];
        int[] adyacencias = new int[numeroVertices];

        System.out.println(Arrays.toString(vertices));
        System.out.println(Arrays.toString(verticesProcesados));
        System.out.println(Arrays.toString(adyacencias));

        int cuentaVertices = 0;
        int auxVertices = numeroVertices;
        
        while (cuentaVertices != auxVertices) {
            if (cuentaVertices == 0) {
                verticesProcesados[verticeInicial] = verticeInicial;
                cuentaVertices++;
                Arista auxArista = listaAdyacencia[verticeInicial].getAdyacencias().getAristaMenor();
                if (auxArista != null) {
                    int destino = auxArista.getDestino();
                    verticesProcesados[destino] = destino;
                    adyacencias[verticeInicial] = destino;
                    cuentaVertices++;
                }                
            } else {
                Arista aristaMenor = null;
                int verticeControl = 0;
                for (int i = 0; i < numeroVertices; i++) {
                    if (vertices[i] != verticesProcesados[i]) {
                        Vertice auxVertice = listaAdyacencia[i];
                        if (aristaMenor == null) {                            
                            aristaMenor = auxVertice.getAdyacencias().getAristaMenor();
                            verticeControl = i;
                        } else {                          
                            Arista auxArista = auxVertice.getAdyacencias().getAristaMenor();
                            if (aristaMenor.getPeso() > auxArista.getPeso()) {
                                aristaMenor = auxArista;
                                verticeControl = i;
                            }
                        }
                    }
                }
                if (aristaMenor != null) {
                    adyacencias[verticeControl] = aristaMenor.getDestino();
                    verticesProcesados[aristaMenor.getDestino()] = aristaMenor.getDestino();
                    cuentaVertices++;
                }
            }
        }*/
 /*Vertice primerVertice = new Vertice(verticeInicial);
        Vertice[] arbol = new Vertice[numeroVertices];         
        
        Arista primeraArista = listaAdyacencia[verticeInicial].getAdyacencias().getAristaMenor();
        int primerDestino = primeraArista.getDestino();
        int primerPeso = primeraArista.getPeso();
        Arista nuevaArista = new Arista(primerDestino,primerPeso);
        
        arbol[verticeInicial] = primerVertice;
        arbol[verticeInicial].getAdyacencias().agregarAlFinal(nuevaArista);
        primerVertice = new Vertice(primerDestino);
        arbol[primerDestino] = primerVertice;
        
        
        Vertice[] auxLista = listaAdyacencia;  
        auxLista[verticeInicial] = null;
        auxLista[primerDestino] = null;
        int cuentaVertices = 2;
        
        while(cuentaVertices != numeroVertices) {
            for (int i = 0;i < numeroVertices - 1; i++) {
                if (arbol[i] != null) {
                    
                    
                }
            }
        } */
        return adyacencias;
    }

}
