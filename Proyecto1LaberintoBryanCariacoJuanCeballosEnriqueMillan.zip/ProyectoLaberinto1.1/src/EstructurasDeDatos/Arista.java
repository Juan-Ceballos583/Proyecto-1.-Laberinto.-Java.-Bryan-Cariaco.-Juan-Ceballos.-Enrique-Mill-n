package EstructurasDeDatos;

/**
 *
 * @author Bryan Cariaco
 */
public class Arista {

    private int destino;
    private int peso;
    private Arista proximo;

    public Arista(int n, int pasillo) {
        destino = n;
        peso = pasillo;
        proximo = null;
    }

    /**
     * @return the destino
     */
    public int getDestino() {
        return destino;
    }

    /**
     * @param destino the destino to set
     */
    public void setDestino(int destino) {
        this.destino = destino;
    }

    /**
     * @return the peso
     */
    public int getPeso() {
        return peso;
    }

    /**
     * @param peso the peso to set
     */
    public void setPeso(int peso) {
        this.peso = peso;
    }

    /**
     * @return the proximo
     */
    public Arista getProximo() {
        return proximo;
    }

    /**
     * @param proximo the proximo to set
     */
    public void setProximo(Arista proximo) {
        this.proximo = proximo;
    }

}
