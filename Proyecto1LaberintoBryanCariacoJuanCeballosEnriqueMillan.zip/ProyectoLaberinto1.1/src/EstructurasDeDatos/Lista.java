package EstructurasDeDatos;

import javax.swing.JOptionPane;

/**
 *
 * @author Bryan Cariaco
 */
public class Lista {

    private Arista primero;
    private int tamaño;

    public Lista() {
        primero = null;
        tamaño = 0;
    }

    public Arista getPrimero() {
        return primero;
    }

    public boolean esVacia() {
        return tamaño == 0;
    }

    public void agregarAlFinal(Arista nuevaArista) {
        if (esVacia()) {
            primero = nuevaArista;
            tamaño++;
        } else {
            Arista auxArista = primero;
            while (auxArista.getProximo() != null) {
                auxArista = auxArista.getProximo();
            }
            auxArista.setProximo(nuevaArista);
            tamaño++;
        }
    }

    public Arista buscarEnLista(int numVertice) {
        Arista encontrado = null;
        if (esVacia()) {
            return encontrado;
        }else{ 
            Arista auxArista = primero;
            while (auxArista.getProximo() != null) {
                if (auxArista.getDestino() == numVertice) {
                    encontrado = auxArista;
                    break;
                }
                auxArista = auxArista.getProximo();
            }

        }
        return encontrado;
    }

    public Arista getAristaMenor() {
        Arista pesoMenor = null;
        if (esVacia()) {
            return pesoMenor;
        } else {
            Arista auxArista = primero;
            Arista menorPesoArista = null;
            while (auxArista.getProximo() != null) {
                if (auxArista.getPeso() > auxArista.getProximo().getPeso()) {
                    menorPesoArista = auxArista.getProximo();
                }
                auxArista = auxArista.getProximo();
            }
            pesoMenor = menorPesoArista;
        }
        return pesoMenor;
    }
    
    public void imprimir() {
        if (esVacia()) {
            JOptionPane.showMessageDialog(null, "Lista vacia");
        } else {
            Arista auxArista = primero;
            while(auxArista.getProximo() != null) {
                System.out.println(auxArista.getDestino());
                auxArista = auxArista.getProximo();
            }
            System.out.println(auxArista.getDestino());
        }
    }
}
