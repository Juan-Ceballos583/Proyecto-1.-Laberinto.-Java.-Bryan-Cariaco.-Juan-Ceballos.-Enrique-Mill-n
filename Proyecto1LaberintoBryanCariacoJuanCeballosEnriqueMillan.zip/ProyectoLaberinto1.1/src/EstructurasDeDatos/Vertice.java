package EstructurasDeDatos;

/**
 *
 * @author Bryan Cariaco
 */
public class Vertice {

    private int num;
    private Lista adyacencias;

    public Vertice(int n) {
        num = n;
        adyacencias = new Lista();
    }

    /**
     * @return the num
     */
    public int getNum() {
        return num;
    }

    /**
     * @param num the num to set
     */
    public void setNum(int num) {
        this.num = num;
    }

    /**
     * @return the adyacencias
     */
    public Lista getAdyacencias() {
        return adyacencias;
    }

    /**
     * @param adyacencias the adyacencias to set
     */
    public void setAdyacencias(Lista adyacencias) {
        this.adyacencias = adyacencias;
    }

}
