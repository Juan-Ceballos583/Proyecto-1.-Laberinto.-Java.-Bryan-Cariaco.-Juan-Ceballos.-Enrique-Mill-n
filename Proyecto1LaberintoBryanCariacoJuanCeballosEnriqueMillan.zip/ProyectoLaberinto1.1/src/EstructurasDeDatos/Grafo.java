package EstructurasDeDatos;

import javax.swing.JOptionPane;

/**
 *
 * @author Bryan Cariaco
 */
public class Grafo {

    private int numVertices;
    private int numMaxVertices;
    private Vertice[] tablaAdyacencia;

    public Grafo(int n) {
        numMaxVertices = n;
        numVertices = 0;
        tablaAdyacencia = new Vertice[numMaxVertices];
    }

    public boolean esVacio() {
        return numVertices == 0;
    }

    public boolean hayEspacio() {
        return numVertices != getNumMaxVertices();
    }

    public boolean existeVertice(int i) {
        return tablaAdyacencia[i] != null;
    }

    public int getNumVertices() {
        return numVertices;
    }

    public void agregarVertice(Vertice nuevoVertice) {
        if (esVacio()) {
            tablaAdyacencia[0] = nuevoVertice;
            numVertices++;
        } else {
            if (hayEspacio()) {
                int auxVertices = getNumMaxVertices();
                for (int i = 0; i < auxVertices; i++) {
                    if (tablaAdyacencia[i] == null) {
                        tablaAdyacencia[i] = nuevoVertice;
                        numVertices++;
                        break;
                    }
                }
            } else {
                JOptionPane.showMessageDialog(null, "No hay espacio para más vertices");
            }
        }
    }

    public boolean adyacente(int verticeOrigen, int verticeDestino) {
        boolean existe = false;
        if (verticeOrigen > getNumMaxVertices() || verticeDestino > getNumMaxVertices()) {
            JOptionPane.showMessageDialog(null, "Vertices inexistentes");
            existe = true;
        } else {
            if (existeVertice(verticeOrigen) && existeVertice(verticeDestino)) {
                Arista auxAristaOrigen = tablaAdyacencia[verticeOrigen].getAdyacencias().buscarEnLista(verticeDestino);
                Arista auxAristaDestino = tablaAdyacencia[verticeDestino].getAdyacencias().buscarEnLista(verticeOrigen);
                boolean existeDesdeOrigen = auxAristaOrigen != null;
                boolean existeDesdeDestino = auxAristaDestino != null;

                if (existeDesdeOrigen || existeDesdeDestino) {
                    existe = true;
                }
            }
        }
        return existe;
    }

    public void agregarArista(int verticeOrigen, int verticeDestino, int peso) {
        if (adyacente(verticeOrigen,verticeDestino)) {
            JOptionPane.showMessageDialog(null, "Vertices inexistentes");
        } else {
            Arista nuevaArista1 = new Arista(verticeDestino, peso);
            Arista nuevaArista2 = new Arista(verticeOrigen, peso);
            tablaAdyacencia[verticeOrigen].getAdyacencias().agregarAlFinal(nuevaArista1);
            tablaAdyacencia[verticeDestino].getAdyacencias().agregarAlFinal(nuevaArista2);
        }
    }

    /**
     * @return the tablaAdyacencia
     */
    public Vertice[] getTablaAdyacencia() {
        return tablaAdyacencia;
    }

    /**
     * @return the numMaxVertices
     */
    public int getNumMaxVertices() {
        return numMaxVertices;
    }
}
